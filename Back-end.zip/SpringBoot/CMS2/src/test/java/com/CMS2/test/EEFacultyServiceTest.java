package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.EEFacultyDAO;
import com.CMS2.Model.EEFacultyModel;
import com.CMS2.Service.EEFacultyService;

public class EEFacultyServiceTest {

    @InjectMocks
    private EEFacultyService eeFacultyService;

    @Mock
    private EEFacultyDAO eeFacultyDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of EEFacultyModel
        List<EEFacultyModel> facultyList = new ArrayList<>();
        facultyList.add(new EEFacultyModel(/* add constructor parameters */));
        facultyList.add(new EEFacultyModel(/* add constructor parameters */));

        // Mock the behavior of eeFacultyDAO.findAll() to return the sample list
        when(eeFacultyDAO.findAll()).thenReturn(facultyList);

        // Call the service method
        List<EEFacultyModel> result = eeFacultyService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(facultyList, result);
    }

    @Test
    public void testSaveStudent() {
        EEFacultyModel facultyModel = new EEFacultyModel(/* add constructor parameters */);

        // Call the service method
        eeFacultyService.saveStudent(facultyModel);

        // Verify that the save method of eeFacultyDAO was called with the expected argument
        verify(eeFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testUpdateStudent() {
        EEFacultyModel facultyModel = new EEFacultyModel(/* add constructor parameters */);

        // Call the service method
        eeFacultyService.updateStudent(facultyModel);

        // Verify that the save method of eeFacultyDAO was called with the expected argument
        verify(eeFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testDeleteStudent() {
        EEFacultyModel facultyModel = new EEFacultyModel(/* add constructor parameters */);

        // Call the service method
        eeFacultyService.deleteStudent(facultyModel);

        // Verify that the delete method of eeFacultyDAO was called with the expected argument
        verify(eeFacultyDAO, times(1)).delete(facultyModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        EEFacultyModel facultyModel = new EEFacultyModel(/* add constructor parameters */);

        // Mock the behavior of eeFacultyDAO.findById() to return an Optional containing facultyModel
        when(eeFacultyDAO.findById(email)).thenReturn(Optional.of(facultyModel));

        // Call the service method
        EEFacultyModel result = eeFacultyService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(facultyModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of eeFacultyDAO.findById() to return an empty Optional
        when(eeFacultyDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        EEFacultyModel result = eeFacultyService.getStudentById(email);

        // Verify that the result is null for a non-existent faculty
        assertNull(result);
    }

    private void assertNull(EEFacultyModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        EEFacultyModel facultyModel = new EEFacultyModel(/* add constructor parameters */);

        // Call the service method
        eeFacultyService.saveUser(facultyModel);

        // Verify that the save method of eeFacultyDAO was called with the expected argument
        verify(eeFacultyDAO, times(1)).save(facultyModel);
    }
}
