package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.StaffDAO;
import com.CMS2.Model.StaffModel;
import com.CMS2.Service.StaffService;

public class StaffServiceTest {

    @InjectMocks
    private StaffService staffService;

    @Mock
    private StaffDAO staffDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of StaffModel
        List<StaffModel> staffList = new ArrayList<>();
        staffList.add(new StaffModel(/* add constructor parameters */));
        staffList.add(new StaffModel(/* add constructor parameters */));

        // Mock the behavior of staffDAO.findAll() to return the sample list
        when(staffDAO.findAll()).thenReturn(staffList);

        // Call the service method
        List<StaffModel> result = staffService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(staffList, result);
    }

    @Test
    public void testSaveStudent() {
        StaffModel staffModel = new StaffModel(/* add constructor parameters */);

        // Call the service method
        staffService.saveStudent(staffModel);

        // Verify that the save method of staffDAO was called with the expected argument
        verify(staffDAO, times(1)).save(staffModel);
    }

    @Test
    public void testUpdateStudent() {
        StaffModel staffModel = new StaffModel(/* add constructor parameters */);

        // Call the service method
        staffService.updateStudent(staffModel);

        // Verify that the save method of staffDAO was called with the expected argument
        verify(staffDAO, times(1)).save(staffModel);
    }

    @Test
    public void testDeleteStudent() {
        StaffModel staffModel = new StaffModel(/* add constructor parameters */);

        // Call the service method
        staffService.deleteStudent(staffModel);

        // Verify that the delete method of staffDAO was called with the expected argument
        verify(staffDAO, times(1)).delete(staffModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        StaffModel staffModel = new StaffModel(/* add constructor parameters */);

        // Mock the behavior of staffDAO.findById() to return an Optional containing staffModel
        when(staffDAO.findById(email)).thenReturn(Optional.of(staffModel));

        // Call the service method
        StaffModel result = staffService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(staffModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of staffDAO.findById() to return an empty Optional
        when(staffDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        StaffModel result = staffService.getStudentById(email);

        // Verify that the result is null for a non-existent staff member
        assertNull(result);
    }

    private void assertNull(StaffModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        StaffModel staffModel = new StaffModel(/* add constructor parameters */);

        // Call the service method
        staffService.saveUser(staffModel);

        // Verify that the save method of staffDAO was called with the expected argument
        verify(staffDAO, times(1)).save(staffModel);
    }
}

