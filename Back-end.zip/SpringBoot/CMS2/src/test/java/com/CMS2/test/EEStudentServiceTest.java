package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.EEStudentDAO;
import com.CMS2.Model.EEStudentModel;
import com.CMS2.Service.EEStudentService;

public class EEStudentServiceTest {

    @InjectMocks
    private EEStudentService eeStudentService;

    @Mock
    private EEStudentDAO eeStudentDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of EEStudentModel
        List<EEStudentModel> studentList = new ArrayList<>();
        EEStudentModel add=(new EEStudentModel(/* add constructor parameters */));
        studentList.add(new EEStudentModel(/* add constructor parameters */));

        // Mock the behavior of eeStudentDAO.findAll() to return the sample list
        when(eeStudentDAO.findAll()).thenReturn(studentList);

        // Call the service method
        List<EEStudentModel> result = eeStudentService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(studentList, result);
    }

    @Test
    public void testSaveStudent() {
        EEStudentModel studentModel = new EEStudentModel(/* add constructor parameters */);

        // Call the service method
        eeStudentService.saveStudent(studentModel);

        // Verify that the save method of eeStudentDAO was called with the expected argument
        verify(eeStudentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testUpdateStudent() {
        EEStudentModel studentModel = new EEStudentModel(/* add constructor parameters */);

        // Call the service method
        eeStudentService.updateStudent(studentModel);

        // Verify that the save method of eeStudentDAO was called with the expected argument
        verify(eeStudentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testDeleteStudent() {
        EEStudentModel studentModel = new EEStudentModel(/* add constructor parameters */);

        // Call the service method
        eeStudentService.deleteStudent(studentModel);

        // Verify that the delete method of eeStudentDAO was called with the expected argument
        verify(eeStudentDAO, times(1)).delete(studentModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        EEStudentModel studentModel = new EEStudentModel(/* add constructor parameters */);

        // Mock the behavior of eeStudentDAO.findById() to return an Optional containing studentModel
        when(eeStudentDAO.findById(email)).thenReturn(Optional.of(studentModel));

        // Call the service method
        EEStudentModel result = eeStudentService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(studentModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of eeStudentDAO.findById() to return an empty Optional
        when(eeStudentDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        EEStudentModel result = eeStudentService.getStudentById(email);

        // Verify that the result is null for a non-existent student
        assertNull(result);
    }

    private void assertNull(EEStudentModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        EEStudentModel studentModel = new EEStudentModel(/* add constructor parameters */);

        // Call the service method
        eeStudentService.saveUser(studentModel);

        // Verify that the save method of eeStudentDAO was called with the expected argument
        verify(eeStudentDAO, times(1)).save(studentModel);
    }
}
