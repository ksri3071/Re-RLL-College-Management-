package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.MarksheetDAO;
import com.CMS2.Model.MarksheetModel;
import com.CMS2.Service.MarksheetService;

public class MarksheetServiceTest {

    @InjectMocks
    private MarksheetService marksheetService;

    @Mock
    private MarksheetDAO marksheetDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of MarksheetModel
        List<MarksheetModel> marksheetList = new ArrayList<>();
        marksheetList.add(new MarksheetModel(/* add constructor parameters */));
        marksheetList.add(new MarksheetModel(/* add constructor parameters */));

        // Mock the behavior of marksheetDAO.findAll() to return the sample list
        when(marksheetDAO.findAll()).thenReturn(marksheetList);

        // Call the service method
        List<MarksheetModel> result = marksheetService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(marksheetList, result);
    }

    @Test
    public void testSaveStudent() {
        MarksheetModel marksheetModel = new MarksheetModel(/* add constructor parameters */);

        // Call the service method
        marksheetService.saveStudent(marksheetModel);

        // Verify that the save method of marksheetDAO was called with the expected argument
        verify(marksheetDAO, times(1)).save(marksheetModel);
    }

    @Test
    public void testUpdateStudent() {
        MarksheetModel marksheetModel = new MarksheetModel(/* add constructor parameters */);

        // Call the service method
        marksheetService.updateStudent(marksheetModel);

        // Verify that the save method of marksheetDAO was called with the expected argument
        verify(marksheetDAO, times(1)).save(marksheetModel);
    }

    @Test
    public void testDeleteStudent() {
        MarksheetModel marksheetModel = new MarksheetModel(/* add constructor parameters */);

        // Call the service method
        marksheetService.deleteStudent(marksheetModel);

        // Verify that the delete method of marksheetDAO was called with the expected argument
        verify(marksheetDAO, times(1)).delete(marksheetModel);
    }
}
