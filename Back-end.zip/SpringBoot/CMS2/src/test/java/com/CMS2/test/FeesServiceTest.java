package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.FeesDAO;
import com.CMS2.Model.FeesModel;
import com.CMS2.Service.FeesService;

public class FeesServiceTest {

    @InjectMocks
    private FeesService feesService;

    @Mock
    private FeesDAO feesDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of FeesModel
        List<FeesModel> feesList = new ArrayList<>();
        feesList.add(new FeesModel(/* add constructor parameters */));
        feesList.add(new FeesModel(/* add constructor parameters */));

        // Mock the behavior of feesDAO.findAll() to return the sample list
        when(feesDAO.findAll()).thenReturn(feesList);

        // Call the service method
        List<FeesModel> result = feesService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(feesList, result);
    }

    @Test
    public void testSaveStudent() {
        FeesModel feesModel = new FeesModel(/* add constructor parameters */);

        // Call the service method
        feesService.saveStudent(feesModel);

        // Verify that the save method of feesDAO was called with the expected argument
        verify(feesDAO, times(1)).save(feesModel);
    }
}
