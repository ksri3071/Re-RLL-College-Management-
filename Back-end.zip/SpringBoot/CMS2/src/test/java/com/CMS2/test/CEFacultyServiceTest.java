package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.CEFacultyDAO;
import com.CMS2.Model.CEFacultyModel;
import com.CMS2.Service.CEFacultyService;

public class CEFacultyServiceTest {

    @InjectMocks
    private CEFacultyService ceFacultyService;

    @Mock
    private CEFacultyDAO ceFacultyDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of CEFacultyModel
        List<CEFacultyModel> facultyList = new ArrayList<>();
        facultyList.add(new CEFacultyModel(/* add constructor parameters */));
        facultyList.add(new CEFacultyModel(/* add constructor parameters */));

        // Mock the behavior of ceFacultyDAO.findAll() to return the sample list
        when(ceFacultyDAO.findAll()).thenReturn(facultyList);

        // Call the service method
        List<CEFacultyModel> result = ceFacultyService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(facultyList, result);
    }

    @Test
    public void testSaveStudent() {
        CEFacultyModel facultyModel = new CEFacultyModel(/* add constructor parameters */);

        // Call the service method
        ceFacultyService.saveStudent(facultyModel);

        // Verify that the save method of ceFacultyDAO was called with the expected argument
        verify(ceFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testUpdateStudent() {
        CEFacultyModel facultyModel = new CEFacultyModel(/* add constructor parameters */);

        // Call the service method
        ceFacultyService.updateStudent(facultyModel);

        // Verify that the save method of ceFacultyDAO was called with the expected argument
        verify(ceFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testDeleteStudent() {
        CEFacultyModel facultyModel = new CEFacultyModel(/* add constructor parameters */);

        // Call the service method
        ceFacultyService.deleteStudent(facultyModel);

        // Verify that the delete method of ceFacultyDAO was called with the expected argument
        verify(ceFacultyDAO, times(1)).delete(facultyModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        CEFacultyModel facultyModel = new CEFacultyModel(/* add constructor parameters */);

        // Mock the behavior of ceFacultyDAO.findById() to return an Optional containing facultyModel
        when(ceFacultyDAO.findById(email)).thenReturn(Optional.of(facultyModel));

        // Call the service method
        CEFacultyModel result = ceFacultyService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(facultyModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of ceFacultyDAO.findById() to return an empty Optional
        when(ceFacultyDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        CEFacultyModel result = ceFacultyService.getStudentById(email);

        // Verify that the result is null for a non-existent faculty
        assertNull(result);
    }

    private void assertNull(CEFacultyModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        CEFacultyModel facultyModel = new CEFacultyModel(/* add constructor parameters */);

        // Call the service method
        ceFacultyService.saveUser(facultyModel);

        // Verify that the save method of ceFacultyDAO was called with the expected argument
        verify(ceFacultyDAO, times(1)).save(facultyModel);
    }
}
