package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.MEFacultyDAO;
import com.CMS2.Model.MEFacultyModel;
import com.CMS2.Service.MEFacultyService;

public class MEFacultyServiceTest {

    @InjectMocks
    private MEFacultyService meFacultyService;

    @Mock
    private MEFacultyDAO meFacultyDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of MEFacultyModel
        List<MEFacultyModel> facultyList = new ArrayList<>();
        facultyList.add(new MEFacultyModel(/* add constructor parameters */));
        facultyList.add(new MEFacultyModel(/* add constructor parameters */));

        // Mock the behavior of meFacultyDAO.findAll() to return the sample list
        when(meFacultyDAO.findAll()).thenReturn(facultyList);

        // Call the service method
        List<MEFacultyModel> result = meFacultyService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(facultyList, result);
    }

    @Test
    public void testSaveStudent() {
        MEFacultyModel facultyModel = new MEFacultyModel(/* add constructor parameters */);

        // Call the service method
        meFacultyService.saveStudent(facultyModel);

        // Verify that the save method of meFacultyDAO was called with the expected argument
        verify(meFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testUpdateStudent() {
        MEFacultyModel facultyModel = new MEFacultyModel(/* add constructor parameters */);

        // Call the service method
        meFacultyService.updateStudent(facultyModel);

        // Verify that the save method of meFacultyDAO was called with the expected argument
        verify(meFacultyDAO, times(1)).save(facultyModel);
    }

    @Test
    public void testDeleteStudent() {
        MEFacultyModel facultyModel = new MEFacultyModel(/* add constructor parameters */);

        // Call the service method
        meFacultyService.deleteStudent(facultyModel);

        // Verify that the delete method of meFacultyDAO was called with the expected argument
        verify(meFacultyDAO, times(1)).delete(facultyModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        MEFacultyModel facultyModel = new MEFacultyModel(/* add constructor parameters */);

        // Mock the behavior of meFacultyDAO.findById() to return an Optional containing facultyModel
        when(meFacultyDAO.findById(email)).thenReturn(Optional.of(facultyModel));

        // Call the service method
        MEFacultyModel result = meFacultyService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(facultyModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of meFacultyDAO.findById() to return an empty Optional
        when(meFacultyDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        MEFacultyModel result = meFacultyService.getStudentById(email);

        // Verify that the result is null for a non-existent faculty
        assertNull(result);
    }

    private void assertNull(MEFacultyModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        MEFacultyModel facultyModel = new MEFacultyModel(/* add constructor parameters */);

        // Call the service method
        meFacultyService.saveUser(facultyModel);

        // Verify that the save method of meFacultyDAO was called with the expected argument
        verify(meFacultyDAO, times(1)).save(facultyModel);
    }
}
