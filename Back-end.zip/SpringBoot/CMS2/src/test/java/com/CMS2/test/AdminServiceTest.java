package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.AdminDAO;
import com.CMS2.Model.AdminModel;
import com.CMS2.Service.AdminService;

public class AdminServiceTest {

    @InjectMocks
    private AdminService adminService;

    @Mock
    private AdminDAO adminDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of AdminModel
        List<AdminModel> adminList = new ArrayList<>();
        adminList.add(new AdminModel(/* add constructor parameters */));
        adminList.add(new AdminModel(/* add constructor parameters */));

        // Mock the behavior of adminDAO.findAll() to return the sample list
        when(adminDAO.findAll()).thenReturn(adminList);

        // Call the service method
        List<AdminModel> result = adminService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(adminList, result);
    }

    @Test
    public void testSaveAdmin() {
        AdminModel adminModel = new AdminModel(/* add constructor parameters */);

        // Call the service method
        adminService.saveAdmin(adminModel);

        // Verify that the save method of adminDAO was called with the expected argument
        verify(adminDAO, times(1)).save(adminModel);
    }

    @Test
    public void testGetAdminById() {
        String email = "test@example.com";
        AdminModel adminModel = new AdminModel(/* add constructor parameters */);

        // Mock the behavior of adminDAO.findById() to return an Optional containing adminModel
        when(adminDAO.findById(email)).thenReturn(Optional.of(adminModel));

        // Call the service method
        AdminModel result = adminService.getAdminById(email);

        // Verify that the result is as expected
        assertEquals(adminModel, result);
    }

    @Test
    public void testGetAdminById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of adminDAO.findById() to return an empty Optional
        when(adminDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        AdminModel result = adminService.getAdminById(email);

        // Verify that the result is null for a non-existent admin
        assertNull(result);
    }

    @Test
    public void testSaveAdmin1() {
        AdminModel adminModel = new AdminModel(/* add constructor parameters */);

        // Call the service method
        adminService.saveAdmin1(adminModel);

        // Verify that the save method of adminDAO was called with the expected argument
        verify(adminDAO, times(1)).save(adminModel);
    }
}
