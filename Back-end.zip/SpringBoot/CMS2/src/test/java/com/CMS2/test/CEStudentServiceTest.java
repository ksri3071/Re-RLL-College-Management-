package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.CEStudentDAO;
import com.CMS2.Model.CEStudentModel;
import com.CMS2.Service.CEStudentService;

public class CEStudentServiceTest {

    @InjectMocks
    private CEStudentService ceStudentService;

    @Mock
    private CEStudentDAO ceStudentDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of CEStudentModel
        List<CEStudentModel> studentList = new ArrayList<>();
        studentList.add(new CEStudentModel(/* add constructor parameters */));
        studentList.add(new CEStudentModel(/* add constructor parameters */));

        // Mock the behavior of ceStudentDAO.findAll() to return the sample list
        when(ceStudentDAO.findAll()).thenReturn(studentList);

        // Call the service method
        List<CEStudentModel> result = ceStudentService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(studentList, result);
    }

    @Test
    public void testSaveStudent() {
        CEStudentModel studentModel = new CEStudentModel(/* add constructor parameters */);

        // Call the service method
        ceStudentService.saveStudent(studentModel);

        // Verify that the save method of ceStudentDAO was called with the expected argument
        verify(ceStudentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testUpdateStudent() {
        CEStudentModel studentModel = new CEStudentModel(/* add constructor parameters */);

        // Call the service method
        ceStudentService.updateStudent(studentModel);

        // Verify that the save method of ceStudentDAO was called with the expected argument
        verify(ceStudentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testDeleteStudent() {
        CEStudentModel studentModel = new CEStudentModel(/* add constructor parameters */);

        // Call the service method
        ceStudentService.deleteStudent(studentModel);

        // Verify that the delete method of ceStudentDAO was called with the expected argument
        verify(ceStudentDAO, times(1)).delete(studentModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        CEStudentModel studentModel = new CEStudentModel(/* add constructor parameters */);

        // Mock the behavior of ceStudentDAO.findById() to return an Optional containing studentModel
        when(ceStudentDAO.findById(email)).thenReturn(Optional.of(studentModel));

        // Call the service method
        CEStudentModel result = ceStudentService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(studentModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of ceStudentDAO.findById() to return an empty Optional
        when(ceStudentDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        CEStudentModel result = ceStudentService.getStudentById(email);

        // Verify that the result is null for a non-existent student
        assertNull(result);
    }

    private void assertNull(CEStudentModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        CEStudentModel studentModel = new CEStudentModel(/* add constructor parameters */);

        // Call the service method
        ceStudentService.saveUser(studentModel);

        // Verify that the save method of ceStudentDAO was called with the expected argument
        verify(ceStudentDAO, times(1)).save(studentModel);
    }
}
