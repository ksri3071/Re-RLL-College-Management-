package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.BranchDAO;
import com.CMS2.Model.BranchModel;
import com.CMS2.Service.BranchService;

public class BranchServiceTest {

    @InjectMocks
    private BranchService branchService;

    @Mock
    private BranchDAO branchDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllBranches() {
        // Create a sample list of BranchModel
        List<BranchModel> branchList = new ArrayList<>();
        branchList.add(new BranchModel(/* add constructor parameters */));
        branchList.add(new BranchModel(/* add constructor parameters */));

        // Mock the behavior of branchDAO.findAll() to return the sample list
        when(branchDAO.findAll()).thenReturn(branchList);

        // Call the service method
        List<BranchModel> result = branchService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(branchList, result);
    }

    @Test
    public void testSaveBranch() {
        BranchModel branchModel = new BranchModel(/* add constructor parameters */);

        // Call the service method
        branchService.saveStudent(branchModel);

        // Verify that the save method of branchDAO was called with the expected argument
        verify(branchDAO, times(1)).save(branchModel);
    }

    @Test
    public void testUpdateBranch() {
        BranchModel branchModel = new BranchModel(/* add constructor parameters */);

        // Call the service method
        branchService.updateStudent(branchModel);

        // Verify that the save method of branchDAO was called with the expected argument
        verify(branchDAO, times(1)).save(branchModel);
    }

    @Test
    public void testDeleteBranch() {
        BranchModel branchModel = new BranchModel(/* add constructor parameters */);

        // Call the service method
        branchService.deleteStudent(branchModel);

        // Verify that the delete method of branchDAO was called with the expected argument
        verify(branchDAO, times(1)).delete(branchModel);
    }
}
