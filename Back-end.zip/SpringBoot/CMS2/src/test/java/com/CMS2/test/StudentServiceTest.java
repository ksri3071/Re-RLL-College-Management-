package com.CMS2.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CMS2.DAO.StudentDAO;
import com.CMS2.Model.StudentModel;
import com.CMS2.Service.StudentService;

public class StudentServiceTest {

    @InjectMocks
    private StudentService studentService;

    @Mock
    private StudentDAO studentDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllLogin() {
        // Create a sample list of StudentModel
        List<StudentModel> studentList = new ArrayList<>();
        studentList.add(new StudentModel(/* add constructor parameters */));
        studentList.add(new StudentModel(/* add constructor parameters */));

        // Mock the behavior of studentDAO.findAll() to return the sample list
        when(studentDAO.findAll()).thenReturn(studentList);

        // Call the service method
        List<StudentModel> result = studentService.getAllLogin();

        // Verify that the result is as expected
        assertEquals(studentList, result);
    }

    @Test
    public void testSaveStudent() {
        StudentModel studentModel = new StudentModel(/* add constructor parameters */);

        // Call the service method
        studentService.saveStudent(studentModel);

        // Verify that the save method of studentDAO was called with the expected argument
        verify(studentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testUpdateStudent() {
        StudentModel studentModel = new StudentModel(/* add constructor parameters */);

        // Call the service method
        studentService.updateStudent(studentModel);

        // Verify that the save method of studentDAO was called with the expected argument
        verify(studentDAO, times(1)).save(studentModel);
    }

    @Test
    public void testDeleteStudent() {
        StudentModel studentModel = new StudentModel(/* add constructor parameters */);

        // Call the service method
        studentService.deleteStudent(studentModel);

        // Verify that the delete method of studentDAO was called with the expected argument
        verify(studentDAO, times(1)).delete(studentModel);
    }

    @Test
    public void testGetStudentById() {
        String email = "test@example.com";
        StudentModel studentModel = new StudentModel(/* add constructor parameters */);

        // Mock the behavior of studentDAO.findById() to return an Optional containing studentModel
        when(studentDAO.findById(email)).thenReturn(Optional.of(studentModel));

        // Call the service method
        StudentModel result = studentService.getStudentById(email);

        // Verify that the result is as expected
        assertEquals(studentModel, result);
    }

    @Test
    public void testGetStudentById_NotFound() {
        String email = "nonexistent@example.com";

        // Mock the behavior of studentDAO.findById() to return an empty Optional
        when(studentDAO.findById(email)).thenReturn(Optional.empty());

        // Call the service method
        StudentModel result = studentService.getStudentById(email);

        // Verify that the result is null for a non-existent student
        assertNull(result);
    }

    private void assertNull(StudentModel result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testSaveUser() {
        StudentModel studentModel = new StudentModel(/* add constructor parameters */);

        // Call the service method
        studentService.saveUser(studentModel);

        // Verify that the save method of studentDAO was called with the expected argument
        verify(studentDAO, times(1)).save(studentModel);
    }
}
