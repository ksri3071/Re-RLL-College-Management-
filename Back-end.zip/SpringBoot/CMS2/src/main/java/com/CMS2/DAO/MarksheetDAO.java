
package com.CMS2.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CMS2.Model.MarksheetModel;

public interface MarksheetDAO extends JpaRepository<MarksheetModel,Integer>{


}
