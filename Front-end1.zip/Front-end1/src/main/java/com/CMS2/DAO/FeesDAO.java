package com.CMS2.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CMS2.Model.FeesModel;

public interface FeesDAO extends JpaRepository<FeesModel,Integer>{


	
}
