
package com.CMS2.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CMS2.Model.BranchModel;

public interface BranchDAO extends JpaRepository<BranchModel,Integer>{


	
}
