package com.CMS2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cms2Application {

	public static void main(String[] args) {
		SpringApplication.run(Cms2Application.class, args);
	}

}
