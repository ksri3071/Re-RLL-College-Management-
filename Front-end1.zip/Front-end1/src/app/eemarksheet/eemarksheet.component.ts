import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eemarksheet',
  templateUrl: './eemarksheet.component.html',
  styleUrls: ['./eemarksheet.component.css']
})
export class EemarksheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
