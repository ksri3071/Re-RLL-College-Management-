import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memarksheet',
  templateUrl: './memarksheet.component.html',
  styleUrls: ['./memarksheet.component.css']
})
export class MemarksheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
