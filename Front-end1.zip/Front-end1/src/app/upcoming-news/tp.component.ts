import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tp',
  templateUrl: './tp.component.html',
  styleUrls: ['./tp.component.css']
})
export class TPComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
