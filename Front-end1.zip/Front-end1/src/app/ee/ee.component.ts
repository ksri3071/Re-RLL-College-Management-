import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ee',
  templateUrl: './ee.component.html',
  styleUrls: ['./ee.component.css']
})
export class EEComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
