import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eesnotice',
  templateUrl: './eesnotice.component.html',
  styleUrls: ['./eesnotice.component.css']
})
export class EesnoticeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
