import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cesnotice',
  templateUrl: './cesnotice.component.html',
  styleUrls: ['./cesnotice.component.css']
})
export class CesnoticeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
