import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cestudentpanel',
  templateUrl: './cestudentpanel.component.html',
  styleUrls: ['./cestudentpanel.component.css']
})
export class CestudentpanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
