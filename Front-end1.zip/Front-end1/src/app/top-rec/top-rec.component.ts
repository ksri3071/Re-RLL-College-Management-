import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-rec',
  templateUrl: './top-rec.component.html',
  styleUrls: ['./top-rec.component.css']
})
export class TopRecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
