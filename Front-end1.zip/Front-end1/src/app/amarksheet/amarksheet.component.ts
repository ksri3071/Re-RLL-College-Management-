import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amarksheet',
  templateUrl: './amarksheet.component.html',
  styleUrls: ['./amarksheet.component.css']
})
export class AmarksheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
