import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-camp-sel',
  templateUrl: './camp-sel.component.html',
  styleUrls: ['./camp-sel.component.css']
})
export class CampSelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
