import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cefacultypanel',
  templateUrl: './cefacultypanel.component.html',
  styleUrls: ['./cefacultypanel.component.css']
})
export class CefacultypanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
