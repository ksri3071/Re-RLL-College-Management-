import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faculty-sign-up',
  templateUrl: './faculty-sign-up.component.html',
  styleUrls: ['./faculty-sign-up.component.css']
})
export class FacultySignUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
