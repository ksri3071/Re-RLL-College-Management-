import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me',
  templateUrl: './me.component.html',
  styleUrls: ['./me.component.css']
})
export class MEComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
