import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ce',
  templateUrl: './ce.component.html',
  styleUrls: ['./ce.component.css']
})
export class CEComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
